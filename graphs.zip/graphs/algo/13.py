class Solution:
    def findTheCity(self, n, edges, distanceThreshold):
        INF = 10**9
        dist = [[INF] * n for _ in range(n)]

        # Distance to itself = 0
        for i in range(n):
            dist[i][i] = 0

        # Add edges
        for u, v, w in edges:
            dist[u][v] = w
            dist[v][u] = w

        # Floyd-Warshall
        for k in range(n):
            for i in range(n):
                for j in range(n):
                    if dist[i][j] > dist[i][k] + dist[k][j]:
                        dist[i][j] = dist[i][k] + dist[k][j]

        # Count reachable cities
        best_city = -1
        best_count = float('inf')

        for i in range(n):
            cnt = 0
            for j in range(n):
                if dist[i][j] <= distanceThreshold:
                    cnt += 1

            if cnt <= best_count:
                best_count = cnt
                best_city = i   # choose larger index on ties

        return best_city
