class Solution:
    def hitBricks(self, grid, hits):
        m, n = len(grid), len(grid[0])

        # Copy grid to apply hits
        copy = [row[:] for row in grid]

        # Apply hits (remove bricks)
        for r, c in hits:
            if copy[r][c] == 1:
                copy[r][c] = 0

        # DSU with ceiling node = m*n
        parent = list(range(m*n + 1))
        size = [1] * (m*n + 1)

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(x, y):
            rx, ry = find(x), find(y)
            if rx == ry:
                return
            if size[rx] < size[ry]:
                rx, ry = ry, rx
            parent[ry] = rx
            size[rx] += size[ry]

        def index(r, c):
            return r*n + c

        CEILING = m*n

        # Union bricks in row 0 with CEILING
        for c in range(n):
            if copy[0][c] == 1:
                union(index(0,c), CEILING)

        # Directions
        dirs = [(1,0),(-1,0),(0,1),(0,-1)]

        # Build DSU for the grid after hits
        for r in range(m):
            for c in range(n):
                if copy[r][c] == 1:
                    for dr, dc in dirs:
                        nr, nc = r+dr, c+dc
                        if 0 <= nr < m and 0 <= nc < n and copy[nr][nc] == 1:
                            union(index(r,c), index(nr,nc))

        res = []
        # Process hits in reverse
        for r, c in reversed(hits):
            if grid[r][c] == 0:
                res.append(0)
                continue

            prev = size[find(CEILING)]

            # Restore brick
            copy[r][c] = 1
            idx = index(r,c)

            # If in top row, union with ceiling
            if r == 0:
                union(idx, CEILING)

            # Union with neighbors
            for dr, dc in dirs:
                nr, nc = r+dr, c+dc
                if 0 <= nr < m and 0 <= nc < n and copy[nr][nc] == 1:
                    union(idx, index(nr,nc))

            new = size[find(CEILING)]
            fallen = max(0, new - prev - 1)
            res.append(fallen)

        return res[::-1]
