from collections import defaultdict
import heapq

class Solution:
    def findItinerary(self, tickets):
        graph = defaultdict(list)

        # Build graph, push destinations into min-heaps
        for u, v in tickets:
            heapq.heappush(graph[u], v)

        route = []

        def dfs(airport):
            dests = graph[airport]
            while dests:
                next_stop = heapq.heappop(dests)
                dfs(next_stop)
            route.append(airport)

        dfs("JFK")
        return route[::-1]
