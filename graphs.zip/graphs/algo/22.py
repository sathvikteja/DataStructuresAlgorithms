class Solution:
    def minSwapsCouples(self, row):
        n = len(row) // 2
        parent = list(range(n))
        size = [1] * n

        def find(x):
            while parent[x] != x:
                parent[x] = parent[parent[x]]
                x = parent[x]
            return x

        def union(a, b):
            pa, pb = find(a), find(b)
            if pa == pb:
                return
            if size[pa] < size[pb]:
                pa, pb = pb, pa
            parent[pb] = pa
            size[pa] += size[pb]

        # Each seat pair: union the couple IDs
        for i in range(0, len(row), 2):
            a = row[i] // 2
            b = row[i+1] // 2
            union(a, b)

        # Count components
        res = 0
        for i in range(n):
            if parent[i] == i:   # root of component
                res += size[i] - 1

        return res
