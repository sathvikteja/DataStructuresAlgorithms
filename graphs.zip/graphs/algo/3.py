# Definition for a binary tree node.
# class TreeNode:
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right

class Solution:
    def rob(self, root):
        def dfs(node):
            if not node:
                return (0, 0)   # (rob, skip)

            left_rob, left_skip = dfs(node.left)
            right_rob, right_skip = dfs(node.right)

            # If we rob this node, we must skip children
            rob = node.val + left_skip + right_skip

            # If we skip this node, take best of children
            skip = max(left_rob, left_skip) + max(right_rob, right_skip)

            return (rob, skip)

        return max(dfs(root))
