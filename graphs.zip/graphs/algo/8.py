# Definition for Employee.
# class Employee:
#     def __init__(self, id: int, importance: int, subordinates: list[int]):
#         self.id = id
#         self.importance = importance
#         self.subordinates = subordinates

class Solution:
    def getImportance(self, employees, id):
        emp = {e.id: e for e in employees}

        def dfs(x):
            person = emp[x]
            total = person.importance
            for sub in person.subordinates:
                total += dfs(sub)
            return total

        return dfs(id)
