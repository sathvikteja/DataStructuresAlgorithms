import heapq

class Solution:
    def networkDelayTime(self, times, n, k):
        graph = [[] for _ in range(n + 1)]

        for u, v, w in times:
            graph[u].append((v, w))

        dist = [float('inf')] * (n + 1)
        dist[k] = 0

        min_heap = [(0, k)]  # (time, node)

        while min_heap:
            cur_time, node = heapq.heappop(min_heap)

            if cur_time > dist[node]:
                continue

            for nei, w in graph[node]:
                if cur_time + w < dist[nei]:
                    dist[nei] = cur_time + w
                    heapq.heappush(min_heap, (dist[nei], nei))

        ans = max(dist[1:])
        return ans if ans < float('inf') else -1
