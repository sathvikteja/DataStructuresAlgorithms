class Solution:
    def numSimilarGroups(self, strs):
        n = len(strs)
        parent = list(range(n))

        def find(x):
            if parent[x] != x:
                parent[x] = find(parent[x])
            return parent[x]

        def union(a, b):
            pa, pb = find(a), find(b)
            if pa != pb:
                parent[pb] = pa

        def similar(a, b):
            diff = 0
            for x, y in zip(a, b):
                if x != y:
                    diff += 1
                    if diff > 2:
                        return False
            return diff == 0 or diff == 2

        # Try all pairs
        for i in range(n):
            for j in range(i+1, n):
                if similar(strs[i], strs[j]):
                    union(i, j)

        # Count distinct groups
        return sum(i == find(i) for i in range(n))
