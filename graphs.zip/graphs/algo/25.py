class Solution:
    def findCriticalAndPseudoCriticalEdges(self, n, edges):
        # Append original index
        edges = [e + [i] for i, e in enumerate(edges)]

        # Union-Find
        def find(x, parent):
            if parent[x] != x:
                parent[x] = find(parent[x], parent)
            return parent[x]

        def union(x, y, parent, rank):
            rx, ry = find(x, parent), find(y, parent)
            if rx == ry:
                return False
            if rank[rx] < rank[ry]:
                rx, ry = ry, rx
            parent[ry] = rx
            rank[rx] += rank[ry]
            return True

        # Build MST function
        def kruskal(ignore_edge=None, pick_edge=None):
            parent = list(range(n))
            rank = [1] * n
            weight = 0

            # If forcing an edge
            if pick_edge is not None:
                u, v, w, _ = pick_edge
                if union(u, v, parent, rank):
                    weight += w

            for u, v, w, idx in edges_sorted:
                if idx == ignore_edge:
                    continue
                if union(u, v, parent, rank):
                    weight += w

            # Check if spanning tree formed
            root = find(0, parent)
            for i in range(1, n):
                if find(i, parent) != root:
                    return float('inf')
            return weight

        # Sort edges by weight
        edges_sorted = sorted(edges, key=lambda x: x[2])

        # Original MST weight
        original_mst = kruskal()

        critical = []
        pseudo = []

        for u, v, w, idx in edges_sorted:
            # Test critical
            if kruskal(ignore_edge=idx) > original_mst:
                critical.append(idx)
            # Test pseudo-critical
            elif kruskal(pick_edge=[u, v, w, idx]) == original_mst:
                pseudo.append(idx)

        return [critical, pseudo]
