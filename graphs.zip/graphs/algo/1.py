class Solution:
    def maximumDetonation(self, bombs: list[list[int]]) -> int:
        n = len(bombs)
        # Build adjacency list: i -> j if j inside i's radius
        graph = [[] for _ in range(n)]
        for i in range(n):
            xi, yi, ri = bombs[i]
            r2 = ri * ri
            for j in range(n):
                if i == j: continue
                xj, yj, _ = bombs[j]
                dx = xi - xj
                dy = yi - yj
                if dx*dx + dy*dy <= r2:
                    graph[i].append(j)

        def reachable_count(start: int) -> int:
            seen = [False] * n
            stack = [start]
            seen[start] = True
            cnt = 0
            while stack:
                u = stack.pop()
                cnt += 1
                for v in graph[u]:
                    if not seen[v]:
                        seen[v] = True
                        stack.append(v)
            return cnt

        ans = 0
        for i in range(n):
            ans = max(ans, reachable_count(i))
        return ans
