from collections import deque

class Solution:
    def widthOfBinaryTree(self, root):
        if not root:
            return 0

        q = deque([(root, 1)])  # (node, index)
        max_width = 0

        while q:
            level_size = len(q)
            _, first = q[0]
            _, last = q[-1]
            max_width = max(max_width, last - first + 1)

            for _ in range(level_size):
                node, idx = q.popleft()

                if node.left:
                    q.append((node.left, idx * 2))
                if node.right:
                    q.append((node.right, idx * 2 + 1))

        return max_width
