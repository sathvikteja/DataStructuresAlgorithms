class Solution:
    def minDays(self, grid):
        m, n = len(grid), len(grid[0])

        def count_islands(g):
            visited = [[False]*n for _ in range(m)]

            def dfs(r, c):
                stack = [(r, c)]
                visited[r][c] = True
                while stack:
                    x, y = stack.pop()
                    for dx, dy in [(1,0),(-1,0),(0,1),(0,-1)]:
                        nx, ny = x+dx, y+dy
                        if 0 <= nx < m and 0 <= ny < n and g[nx][ny] == 1 and not visited[nx][ny]:
                            visited[nx][ny] = True
                            stack.append((nx, ny))

            count = 0
            for i in range(m):
                for j in range(n):
                    if g[i][j] == 1 and not visited[i][j]:
                        count += 1
                        if count > 1:   # optimization
                            return count
                        dfs(i, j)
            return count

        # Step 1: already disconnected?
        if count_islands(grid) != 1:
            return 0

        # Step 2: try removing each land cell
        for i in range(m):
            for j in range(n):
                if grid[i][j] == 1:
                    grid[i][j] = 0
                    if count_islands(grid) != 1:
                        grid[i][j] = 1
                        return 1
                    grid[i][j] = 1

        # Step 3: otherwise answer = 2
        return 2
