from collections import defaultdict

class Solution:
    def calcEquation(self, equations, values, queries):
        graph = defaultdict(list)

        # Build graph
        for (a, b), val in zip(equations, values):
            graph[a].append((b, val))
            graph[b].append((a, 1 / val))

        def dfs(cur, target, visited, value):
            if cur == target:
                return value
            visited.add(cur)

            for nei, w in graph[cur]:
                if nei not in visited:
                    res = dfs(nei, target, visited, value * w)
                    if res != -1:
                        return res

            return -1

        ans = []
        for x, y in queries:
            if x not in graph or y not in graph:
                ans.append(-1.0)
            else:
                ans.append(dfs(x, y, set(), 1.0))

        return ans
