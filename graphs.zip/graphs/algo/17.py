class Solution:
    def minimumCost(self, source, target, original, changed, cost):
        INF = 10**15
        dist = [[INF] * 26 for _ in range(26)]

        # Distance to itself = 0
        for i in range(26):
            dist[i][i] = 0

        # Add all edges
        for o, c, w in zip(original, changed, cost):
            u = ord(o) - 97
            v = ord(c) - 97
            dist[u][v] = min(dist[u][v], w)

        # Floyd–Warshall for 26 letters
        for k in range(26):
            for i in range(26):
                for j in range(26):
                    if dist[i][j] > dist[i][k] + dist[k][j]:
                        dist[i][j] = dist[i][k] + dist[k][j]

        total_cost = 0

        # Compute total cost for each character
        for s, t in zip(source, target):
            if s == t:
                continue
            u = ord(s) - 97
            v = ord(t) - 97
            if dist[u][v] >= INF:
                return -1
            total_cost += dist[u][v]

        return total_cost
