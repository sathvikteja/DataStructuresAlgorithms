class Solution:
    def findRedundantDirectedConnection(self, edges):
        n = len(edges)
        parent = [0] * (n + 1)
        cand1 = cand2 = None

        # Step 1: Check for a node with two parents
        for u, v in edges:
            if parent[v] == 0:
                parent[v] = u
            else:
                cand1 = (parent[v], v)  # earlier edge
                cand2 = (u, v)          # later edge
                break

        def find(x, root):
            if root[x] != x:
                root[x] = find(root[x], root)
            return root[x]

        # Step 2: Union-Find ignoring cand2
        root = list(range(n + 1))

        for u, v in edges:
            if (u, v) == cand2:
                continue  # skip second parent edge

            pu = find(u, root)
            pv = find(v, root)
            if pu == pv:   # cycle found
                # If no two-parent conflict → return current edge
                if cand1 is None:
                    return [u, v]
                # If there is conflict → return earlier edge
                return list(cand1)
            root[pv] = pu

        # If no cycle when skipping cand2 → cand2 is answer
        return list(cand2)
