from collections import defaultdict, deque

class Solution:
    def validArrangement(self, pairs):
        graph = defaultdict(deque)
        indeg = defaultdict(int)
        outdeg = defaultdict(int)

        # Build graph
        for u, v in pairs:
            graph[u].append(v)
            outdeg[u] += 1
            indeg[v] += 1

        # Find start node for Eulerian path
        start = pairs[0][0]
        for x in graph:
            if outdeg[x] - indeg[x] == 1:
                start = x
                break

        path = []

        # Hierholzer DFS
        def dfs(u):
            while graph[u]:
                v = graph[u].popleft()
                dfs(v)
                path.append([u, v])

        dfs(start)
        path.reverse()
        return path
