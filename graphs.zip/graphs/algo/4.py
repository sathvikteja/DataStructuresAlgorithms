class Solution:
    def canMeasureWater(self, x, y, z):

        def gcd(a, b):
            while b:
                a, b = b, a % b
            return a

        if z > x + y:
            return False

        return z % gcd(x, y) == 0
