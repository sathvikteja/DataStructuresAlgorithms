class Solution:
    def loudAndRich(self, richer, quiet):
        n = len(quiet)

        # Build graph: u -> v (u richer than v)
        graph = [[] for _ in range(n)]
        for u, v in richer:
            graph[v].append(u)

        ans = [-1] * n

        def dfs(x):
            if ans[x] != -1:
                return ans[x]

            # Initially assume x is the quietest
            quietest = x

            # Check all richer persons
            for nei in graph[x]:
                cand = dfs(nei)
                if quiet[cand] < quiet[quietest]:
                    quietest = cand

            ans[x] = quietest
            return quietest

        # Compute for each person
        for i in range(n):
            dfs(i)

        return ans
