import heapq

class Solution:
    def minCostConnectPoints(self, points):
        n = len(points)
        visited = [False] * n
        min_heap = [(0, 0)]  # (cost, starting_node)
        total = 0
        edges_used = 0

        while edges_used < n:
            cost, u = heapq.heappop(min_heap)

            if visited[u]:
                continue

            visited[u] = True
            total += cost
            edges_used += 1

            # Push edges from u to all unvisited nodes
            x1, y1 = points[u]
            for v in range(n):
                if not visited[v]:
                    x2, y2 = points[v]
                    dist = abs(x1 - x2) + abs(y1 - y2)
                    heapq.heappush(min_heap, (dist, v))

        return total
