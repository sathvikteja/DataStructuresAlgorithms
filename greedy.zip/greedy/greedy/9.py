class Solution:
    def turtleMexSum(self, n, m, sets):
        mexes = []
        for s in sets:
            sset = set(s)
            mex = 0
            while mex in sset:
                mex += 1
            mexes.append(mex)

        max_mex = max(mexes)
        if m < max_mex:
            return (m + 1) * max_mex
        else:
            const_part = max_mex * max_mex
            var_part = (m * (m + 1) // 2) - ((max_mex - 1) * max_mex // 2)
            return const_part + var_part
