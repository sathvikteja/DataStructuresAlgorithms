class Solution:
    def maximizeLast(self, a):
        n = len(a)
        max_val = 0
        for i in range(0, n, 2):
            if a[i] > max_val:
                max_val = a[i]
        return max_val


sol = Solution()
print(sol.maximizeLast([4,7,4,2,9]))
