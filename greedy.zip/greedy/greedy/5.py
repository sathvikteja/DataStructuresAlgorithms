def main():
    import sys
    input = sys.stdin.readline

    t = int(input().strip())
    for _ in range(t):
        n = int(input().strip())
        a = list(map(int, input().split()))
        sol = Solution()
        k = sol.makeAlmostEqualWithMod(a)
        print(k)

if __name__ == "__main__":
    main()
