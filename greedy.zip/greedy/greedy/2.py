class Solution:
    def fractionalKnapsack(self, val, wt, capacity):
        n = len(val)
        items = []
        for i in range(n):
            ratio = val[i] / wt[i]
            items.append((ratio, val[i], wt[i]))

        items.sort(reverse=True)

        total_value = 0.0
        for ratio, value, weight in items:
            if capacity >= weight:
                capacity -= weight
                total_value += value
            else:
                total_value += ratio * capacity
                break

        return total_value
