import heapq

class Solution:
    def maxPotions(self, potions):
        total = 0
        heap = []

        for x in potions:
            total += x
            heapq.heappush(heap, x)
            if total < 0:
                total -= heapq.heappop(heap)

        return len(heap)
