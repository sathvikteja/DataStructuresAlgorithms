import sys
input = sys.stdin.readline

class Solution:
    def solve(self):
        t = int(input().strip())
        for _ in range(t):
            n = int(input().strip())
            a = list(map(int, input().split()))
            total = sum(a)
            subtract = a[n-2]
            ans = total - 2 * subtract
            print(ans)

if __name__ == "__main__":
    Solution().solve()
