class Solution:
    def makesquare(self, matchsticks):
        total = sum(matchsticks)
        if total % 4: return False
        side = total // 4
        matchsticks.sort(reverse=True)
        sides = [0] * 4

        def dfs(i):
            if i == len(matchsticks):
                return all(s == side for s in sides)
            for j in range(4):
                if sides[j] + matchsticks[i] <= side:
                    sides[j] += matchsticks[i]
                    if dfs(i + 1): return True
                    sides[j] -= matchsticks[i]
            return False

        return dfs(0)
