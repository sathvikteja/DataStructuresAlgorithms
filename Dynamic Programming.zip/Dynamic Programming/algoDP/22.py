from functools import lru_cache

class Solution:
    def minNumberOfSemesters(self, n, relations, k):
        pre = [0] * n
        for u, v in relations:
            pre[v-1] |= 1 << (u-1)

        @lru_cache(None)
        def dfs(mask):
            if mask == (1 << n) - 1:
                return 0
            avail = [i for i in range(n) if not (mask >> i) & 1 and (pre[i] & mask) == pre[i]]
            ans = float('inf')
            for subset in self.subsets(avail, k):
                new_mask = mask
                for i in subset:
                    new_mask |= 1 << i
                ans = min(ans, 1 + dfs(new_mask))
            return ans

        return dfs(0)

    def subsets(self, arr, k):
        res = []
        def backtrack(start, path):
            if len(path) == k or start == len(arr):
                res.append(path[:])
                return
            for i in range(start, len(arr)):
                path.append(arr[i])
                backtrack(i + 1, path)
                path.pop()
        backtrack(0, [])
        return res
