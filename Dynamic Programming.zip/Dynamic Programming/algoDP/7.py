class Solution:
    def lenLongestFibSubseq(self, arr):
        n = len(arr)
        index = {x:i for i, x in enumerate(arr)}
        dp = {}
        res = 0
        for i in range(n):
            for j in range(i):
                k = index.get(arr[i] - arr[j])
                if k is not None and k < j:
                    dp[j, i] = dp.get((k, j), 2) + 1
                    res = max(res, dp[j, i])
        return res
