class Solution:
    def minCoins(self, coins, target):
        dp = [float('inf')] * (target + 1)
        dp[0] = 0
        for c in coins:
            for t in range(c, target + 1):
                dp[t] = min(dp[t], dp[t - c] + 1)
        return dp[target] if dp[target] != float('inf') else -1
