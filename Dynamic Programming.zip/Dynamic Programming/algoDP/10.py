class Solution:
    def twoEggDrop(self, n: int) -> int:
        # dp[m] = maximum number of floors that can be checked with m moves
        # and 2 eggs
        m = 0
        curr = 0
        while curr < n:
            m += 1
            curr += m
        return m
