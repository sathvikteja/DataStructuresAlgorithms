class Solution:
    def minimumTime(self, s):
        n = len(s)
        left = [0]*n
        right = [0]*n
        if s[0] == '1': left[0] = 1
        for i in range(1, n):
            if s[i] == '1':
                left[i] = min(left[i-1] + 2, i + 1)
            else:
                left[i] = left[i-1]
        res = left[-1]
        r = 0
        for i in range(n-1, -1, -1):
            res = min(res, left[i-1] + r if i > 0 else r)
            if s[i] == '1':
                r = min(r + 2, n - i)
        return res
