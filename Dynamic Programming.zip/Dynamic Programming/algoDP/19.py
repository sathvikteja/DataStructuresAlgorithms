from functools import lru_cache


class Solution:
    def canIWin(self, maxChoosable, desiredTotal):
        if (maxChoosable * (maxChoosable + 1)) // 2 < desiredTotal:
            return False

        @lru_cache(None)
        def dfs(used, total):
            for i in range(1, maxChoosable + 1):
                if not (used >> i) & 1:
                    if total + i >= desiredTotal or not dfs(used | (1 << i), total + i):
                        return True
            return False

        return dfs(0, 0)
