class Solution:
    def splitArray(self, nums, k):
        n = len(nums)
        prefix = [0]
        for x in nums:
            prefix.append(prefix[-1] + x)
        dp = [[float('inf')] * (k+1) for _ in range(n+1)]
        dp[0][0] = 0

        for i in range(1, n+1):
            for j in range(1, k+1):
                for p in range(i):
                    dp[i][j] = min(dp[i][j], max(dp[p][j-1], prefix[i] - prefix[p]))
        return dp[n][k]
