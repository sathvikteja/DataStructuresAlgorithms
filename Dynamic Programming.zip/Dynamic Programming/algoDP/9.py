class Solution:
    def numTeams(self, rating):
        n = len(rating)
        ans = 0
        for j in range(n):
            left_sm = left_lg = right_sm = right_lg = 0
            for i in range(j):
                if rating[i] < rating[j]:
                    left_sm += 1
                elif rating[i] > rating[j]:
                    left_lg += 1
            for k in range(j+1, n):
                if rating[k] < rating[j]:
                    right_sm += 1
                elif rating[k] > rating[j]:
                    right_lg += 1
            ans += left_sm * right_lg + left_lg * right_sm
        return ans
