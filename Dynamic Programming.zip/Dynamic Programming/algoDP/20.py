class Solution:
    def canPartitionKSubsets(self, nums, k):
        total = sum(nums)
        if total % k: return False
        target = total // k
        nums.sort(reverse=True)
        n = len(nums)

        dp = [-1] * (1 << n)
        dp[0] = 0

        for mask in range(1 << n):
            if dp[mask] == -1: continue
            for i in range(n):
                if not (mask >> i) & 1 and dp[mask] + nums[i] <= target:
                    nxt = mask | (1 << i)
                    dp[nxt] = (dp[mask] + nums[i]) % target
        return dp[(1 << n) - 1] == 0
