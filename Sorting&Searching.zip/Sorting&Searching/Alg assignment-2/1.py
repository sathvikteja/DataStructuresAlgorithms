class Solution(object):
    def first_occurrence(self, nums, x):
        l, h = 0, len(nums) - 1
        ans = -1
        while l <= h:
            mid = (l + h) // 2
            if nums[mid] == x:
                ans = mid
                h = mid - 1  # move left to find earlier occurrence
            elif nums[mid] < x:
                l = mid + 1
            else:
                h = mid - 1
        return ans

    def last_occurrence(self, nums, x):
        l, h = 0, len(nums) - 1
        ans = -1
        while l <= h:
            mid = (l + h) // 2
            if nums[mid] == x:
                ans = mid
                l = mid + 1  # move right to find later occurrence
            elif nums[mid] < x:
                l = mid + 1
            else:
                h = mid - 1
        return ans

    def searchRange(self, nums, target):
        """
        :type nums: List[int]
        :type target: int
        :rtype: List[int]
        """

        return [self.first_occurrence(nums, target), self.last_occurrence(nums, target)]

