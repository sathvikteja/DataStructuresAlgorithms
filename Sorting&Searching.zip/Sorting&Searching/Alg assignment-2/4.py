class Solution(object):
    def maxValue(self, n, i, mS):
        """
        :type n: int
        :type index: int
        :type maxSum: int
        :rtype: int
        """

        def can(l, val, mS, n):
            sum = val
            sum += calc(l, val - 1)
            sum += calc(n - l - 1, val - 1)
            return sum <= mS

        def calc(l, val):
            if l < val:
                first = val - l + 1
                last = val
                return ((last + first) * l) // 2
            else:
                return val * (val + 1) / 2 + l - val

        l = 1
        h = mS
        ans = 1
        while (l <= h):
            mid = (l + h) // 2
            if can(i, mid, mS, n):
                ans = mid
                l = mid + 1
            else:
                h = mid - 1
        return ans
