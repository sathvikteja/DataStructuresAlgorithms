class Solution(object):
    def possible(self,bloomDay,m,k,y):
        n=len(bloomDay)
        x=0
        for i in range(n):
            if bloomDay[i]<=y:
                x+=1
            else:
                x=0
            if x==k:
                m-=1
                x=0
        if m<=0:
            return y
        else:
            return -1
    def minDays(self,bloomDay, m, k):
        """
        :type bloomDay: List[int]
        :type m: int
        :type k: int
        :rtype: int
        """
        n=len(bloomDay)
        if m*k>n:
            return -1
        l=min(bloomDay)
        h=max(bloomDay)
        ans = -1
        while(l<=h):
            mid=(l+h)//2
            if self.possible(bloomDay,m,k,mid)==-1:
                l=mid+1
            else:
                ans = mid
                h=mid-1
        return ans
