class Solution(object):
    def nthMagicalNumber(self, n, a, b):
        """
        :type n: int
        :type a: int
        :type b: int
        :rtype: int
        """
        def gcd(a, b):
            while b:
                a, b = b, a % b
            return a
        def lcm(a,b):
            return a*b//gcd(a,b)

        MOD=10**9 + 7
        l=min(a,b)
        h=n*min(a,b)
        while(l<h):
            mid=(l+h)//2
            x=mid//a + mid//b - mid//lcm(a,b)
            if x<n:
                l=mid+1
            else:
                h=mid
        return l% MOD