class Solution(object):
    def singleNonDuplicate(self, nums):
        n = len(nums)
        if n == 1:
            return nums[0]
        if nums[0] != nums[1]:
            return nums[0]
        elif nums[n - 1] != nums[n - 2]:
            return nums[n - 1]
        l = 1
        h = len(nums) - 2
        while (l <= h):
            mid = (l + h) // 2
            if nums[mid - 1] != nums[mid] and nums[mid + 1] != nums[mid]:
                return nums[mid]
            if mid % 2 == 0:
                if nums[mid - 1] == nums[mid]:
                    h = mid - 1
                else:
                    l = mid + 1
            else:
                if nums[mid - 1] == nums[mid]:
                    l = mid + 1
                else:
                    h = mid - 1

        """
        :type nums: List[int]
        :rtype: int
        """
