class Solution(object):
    def findMinDifference(self, timePoints):
        """
        :type timePoints: List[str]
        :rtype: int
        """
        n = len(timePoints)
        for i in range(n):
            timePoints[i] = timePoints[i].split(':')
            for j in range(len(timePoints[i])):
                timePoints[i][j] = int(timePoints[i][j])
            timePoints[i] = timePoints[i][0] * 60 + timePoints[i][1]
        timePoints.sort()

        m = 1440
        for i in range(n):
            k = abs(timePoints[i] - timePoints[(i + 1) % n])
            if min(k, 1440 - k) < m:
                m = min(k, 1440 - k)
        return m
