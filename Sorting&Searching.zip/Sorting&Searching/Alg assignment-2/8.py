class Solution(object):
    def intersect(self, nums1, nums2):
        """
        :type nums1: List[int]
        :type nums2: List[int]
        :rtype: List[int]
        """
        n1 = len(nums1)
        n2 = len(nums2)
        nums1.sort()
        nums2.sort()
        l1 = 0
        l2 = 0
        res = []
        while (l1 <= n1 - 1 and l2 <= n2 - 1):
            if nums1[l1] < nums2[l2]:
                l1 += 1
            elif nums1[l1] > nums2[l2]:
                l2 += 1
            else:
                res += [nums1[l1]]
                l1 += 1
                l2 += 1
        return res
