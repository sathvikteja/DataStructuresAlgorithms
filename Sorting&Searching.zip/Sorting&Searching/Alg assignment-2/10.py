class Solution(object):
    def reversePairs(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """

        def mergesort(l, h):
            if l >= h:
                return 0
            mid = (l + h) // 2
            count = mergesort(l, mid) + mergesort(mid + 1, h)

            # count reverse
            j = mid + 1
            for i in range(l, mid + 1):
                while (j <= h and nums[i] > 2 * nums[j]):
                    j += 1
                count += j - (mid + 1)

            # merge
            temp = []
            i = l
            j = mid + 1
            while (i <= mid and j <= h):
                if nums[i] <= nums[j]:
                    temp.append(nums[i])
                    i += 1
                else:
                    temp.append(nums[j])
                    j += 1
            while (i <= mid):
                temp.append(nums[i])
                i += 1
            while (j <= h):
                temp.append(nums[j])
                j += 1

            nums[l:h + 1] = temp
            return count

        return mergesort(0, len(nums) - 1)


