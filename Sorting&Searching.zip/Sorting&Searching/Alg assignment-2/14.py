class Solution(object):
    def threeSumClosest(self, nums, target):
        """
        :type nums: List[int]
        :type target: int
        :rtype: int
        """
        nums.sort()
        n=len(nums)
        closest=nums[0]+nums[1]+nums[2]
        for i in range(n-2):
            if i>0 and nums[i]==nums[i-1]:
                continue
            l=i+1
            r=n-1
            while(l<r):
                tot=nums[l]+nums[r]+nums[i]
                if abs(tot-target)<abs(target-closest):
                    closest=tot
                elif tot<target:
                    l+=1
                elif tot>target:
                    r-=1
                else:
                    return tot
        return closest