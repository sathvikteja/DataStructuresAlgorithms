class Solution(object):
    def countBadPairs(self, nums):
        """
        :type nums: List[int]
        :rtype: int
        """
        n = len(nums)
        total = (n * (n - 1)) // 2
        good = 0
        seen = {}
        for i, x in enumerate(nums):
            key = x - i
            if key in seen:
                good += seen[key]  # all earlier indices with same key
                seen[key] += 1
            else:
                seen[key] = 1
        return total - good


