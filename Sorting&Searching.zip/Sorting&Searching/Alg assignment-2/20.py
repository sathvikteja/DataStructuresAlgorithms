class Solution(object):
    def checkSubarraySum(self, nums, k):
        """
        :type nums: List[int]
        :type k: int
        :rtype: bool
        """
        seen = {0: -1}
        total = 0

        for i, x in enumerate(nums):
            total += x
            rem = total % k if k != 0 else total
            if rem in seen:
                if i - seen[rem] > 1:
                    return True
            else:
                seen[rem] = i
        return False
