class Solution(object):
    def isIdealPermutation(self, nums):
        """
        :type nums: List[int]
        :rtype: bool
        """
        m=0
        for i in range(len(nums)-2):
            m=max(m,nums[i])
            if m>nums[i+2]:
                return False
        return True