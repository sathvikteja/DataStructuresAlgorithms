class Solution(object):
    def threeSum(self, nums):
        """
        :type nums: List[int]
        :rtype: List[List[int]]
        """
        nums.sort()
        triplets=[]
        for k in range(len(nums)-2):
            if(k>0 and nums[k]==nums[k-1]):
                continue
            l=k+1
            r=len(nums)-1
            while(l<r):
                tot=nums[l]+nums[r]+nums[k]
                if tot==0:
                    triplets.append([nums[k],nums[l],nums[r]])
                    l+=1
                    while(l<r and nums[l]==nums[l-1]):
                        l+=1
                    r-=1
                    while(l<r and nums[r]==nums[r+1]):
                        r-=1
                elif tot<0:
                    l+=1
                else:
                    r-=1
        return triplets