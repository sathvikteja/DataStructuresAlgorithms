class Solution(object):
    def matrixSum(self, nums):
        """
        :type nums: List[List[int]]
        :rtype: int
        """
        for i in nums:
            i.sort()
        return sum(max(col) for col in zip(*nums))

