class SegmentTree:
    def __init__(self, n):
        self.n = n
        self.tree = [0] * (4 * n)

    def update(self, idx, l, r, pos, val):
        if l == r:
            self.tree[idx] = max(self.tree[idx], val)
            return
        mid = (l + r) // 2
        if pos <= mid:
            self.update(2*idx, l, mid, pos, val)
        else:
            self.update(2*idx+1, mid+1, r, pos, val)
        self.tree[idx] = max(self.tree[2*idx], self.tree[2*idx+1])

    def query(self, idx, l, r, ql, qr):
        if qr < l or r < ql:
            return 0
        if ql <= l and r <= qr:
            return self.tree[idx]
        mid = (l + r) // 2
        return max(
            self.query(2*idx, l, mid, ql, qr),
            self.query(2*idx+1, mid+1, r, ql, qr)
        )
class Solution(object):
    def lengthOfLIS(self, nums, k):
        """
        :type nums: List[int]
        :type k: int
        :rtype: int
        """
        # Coordinate compression
        unique_vals = sorted(set(nums))
        rank = {v: i+1 for i, v in enumerate(unique_vals)}
        n = len(unique_vals)

        seg = SegmentTree(n)
        res = 0

        for x in nums:
            # valid range: [x-k, x-1]
            left_val = x - k
            right_val = x - 1

            # find compressed indices
            # bisect to map ranges
            import bisect
            l = bisect.bisect_left(unique_vals, left_val)
            r = bisect.bisect_right(unique_vals, right_val) - 1

            best = 0
            if l <= r:
                best = seg.query(1, 1, n, l+1, r+1)

            cur = best + 1
            seg.update(1, 1, n, rank[x], cur)
            res = max(res, cur)

        return res