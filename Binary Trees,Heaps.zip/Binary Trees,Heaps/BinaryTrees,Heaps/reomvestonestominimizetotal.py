class Solution(object):
    def minStoneSum(self, piles, k):
        """
        :type piles: List[int]
        :type k: int
        :rtype: int
        """
        heap=[-pile for pile in piles]
        heapq.heapify(heap)
        while k>0:
            l=-heapq.heappop(heap)
            heapq.heappush(heap,-(l-(l//2)))
            k-=1
        return -sum(heap)