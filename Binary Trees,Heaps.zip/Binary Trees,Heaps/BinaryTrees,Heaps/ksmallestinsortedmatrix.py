class Solution(object):
    def kthSmallest(self, matrix, k):
        """
        :type matrix: List[List[int]]
        :type k: int
        :rtype: int
        """
        # heap=[]
        # for i in range(len(matrix)):
        #     for j in range(len(matrix[0])):
        #         heapq.heappush(heap,-matrix[i][j])
        #         if len(heap)>k:
        #             heapq.heappop(heap)
        # return -heap[0]
        n = len(matrix)

        def count(mid):
            count = 0
            row = n - 1
            col = 0
            while row >= 0 and col < n:
                if matrix[row][col] <= mid:
                    count += row + 1
                    col += 1
                else:
                    row -= 1
            return count

        l = matrix[0][0]
        h = matrix[n - 1][n - 1]
        while l < h:
            mid = (l + h) // 2
            if count(mid) < k:
                l = mid + 1
            else:
                h = mid
        return l
