class SegTree:
    def __init__(self, arr):
        self.n = len(arr)
        size = 1
        while size < self.n:
            size <<= 1
        self.size = size
        self.tree = [-10**18] * (2 * size)
        for i in range(self.n):
            self.tree[size + i] = arr[i]
        for i in range(size - 1, 0, -1):
            self.tree[i] = max(self.tree[2 * i], self.tree[2 * i + 1])

    def query_max(self, l, r):
        if l > r:
            return -10**18
        l += self.size
        r += self.size
        res = -10**18
        while l <= r:
            if l & 1:
                res = max(res, self.tree[l])
                l += 1
            if r % 2 == 0:
                res = max(res, self.tree[r])
                r -= 1
            l //= 2
            r //= 2
        return res

    def find_first_ge(self, ql, qr, target):
        if ql > qr or ql >= self.n:
            return -1
        if qr >= self.n:
            qr = self.n - 1
        if self.query_max(ql, qr) < target:
            return -1
        return self._find(1, 0, self.size - 1, ql, qr, target)

    def _find(self, idx, l, r, ql, qr, target):
        if ql > r or qr < l or self.tree[idx] < target:
            return -1
        if l == r:
            return l if l < self.n else -1
        mid = (l + r) // 2
        left = self._find(idx * 2, l, mid, ql, qr, target)
        if left != -1:
            return left
        return self._find(idx * 2 + 1, mid + 1, r, ql, qr, target)


class Solution:
    def leftmostBuildingQueries(self, heights, queries):
        n = len(heights)
        st = SegTree(heights)
        ans = []

        for a, b in queries:
            if a == b:
                ans.append(a)
                continue

            L, R = min(a, b), max(a, b)

            if heights[L] < heights[R]:
                ans.append(R)
                continue

            h = max(heights[a], heights[b])
            start = R + 1
            if start >= n:
                ans.append(-1)
                continue

            pos = st.find_first_ge(start, n - 1, h + 1)
            ans.append(pos if pos != -1 else -1)

        return ans
