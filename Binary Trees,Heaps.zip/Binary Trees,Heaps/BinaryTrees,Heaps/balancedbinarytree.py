# Definition for a binary tree node.
# class TreeNode(object):
#     def __init__(self, val=0, left=None, right=None):
#         self.val = val
#         self.left = left
#         self.right = right
class Solution(object):
    def isBalanced(self, root):
        """
        :type root: Optional[TreeNode]
        :rtype: bool
        """

        # def height(node):
        #     if node is None:
        #         return 0
        #     return 1+max(height(node.left),height(node.right))
        # q=deque([root])

        # while q:
        #     node=q.popleft()
        #     if node and abs(height(node.left)-height(node.right))>1:
        #             return False
        #     if node and node.left:
        #         q.append(node.left)
        #     if node and node.right:
        #         q.append(node.right)
        # return True
        def check(node):
            if node is None:
                return 0
            l = check(node.left)
            if l == -1:
                return -1
            r = check(node.right)
            if r == -1:
                return -1
            if abs(l - r) > 1:
                return -1
            return 1 + max(l, r)

        return check(root) != -1