class BIT:
    def __init__(self, size):
        self.size = size + 2
        self.tree = [0] * self.size

    def update(self, index, val=1):
        while index < self.size:
            self.tree[index] += val
            index += index & -index

    def query(self, index):
        res = 0
        while index > 0:
            res += self.tree[index]
            index -= index & -index
        return res


class Solution:
    def reversePairs(self, nums):
        # Collect all unique numbers and their doubles for coordinate compression
        all_numbers = set(nums)
        all_numbers.update([2 * x for x in nums])
        sorted_nums = sorted(all_numbers)

        # Map value to index for BIT (1-based)
        val_to_idx = {v: i + 1 for i, v in enumerate(sorted_nums)}

        bit = BIT(len(sorted_nums))
        result = 0

        # Traverse from right to left
        for num in reversed(nums):
            # Count of numbers less than num -> 2*num in BIT
            idx = val_to_idx[num] - 1  # query numbers < num
            result += bit.query(idx)
            # Add 2*num to BIT
            bit.update(val_to_idx[2 * num])

        return result


