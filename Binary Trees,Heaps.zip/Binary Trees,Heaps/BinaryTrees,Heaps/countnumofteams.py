class BIT:
    def __init__(self, n):
        self.n = n
        self.tree = [0] * (n + 1)

    def update(self, i, delta):
        while i <= self.n:
            self.tree[i] += delta
            i += i & -i

    def query(self, i):
        """sum of frequencies up to index i"""
        s = 0
        while i > 0:
            s += self.tree[i]
            i -= i & -i
        return s


class Solution:
    def numTeams(self, rating):
        n = len(rating)
        # compress values (BIT requires small range)
        sorted_vals = sorted(set(rating))
        rank = {val: i + 1 for i, val in enumerate(sorted_vals)}  # 1-based indexing for BIT

        # BITs for left and right
        leftBIT = BIT(len(sorted_vals))
        rightBIT = BIT(len(sorted_vals))

        # Initially, all elements are on the right
        for val in rating:
            rightBIT.update(rank[val], 1)

        res = 0
        for val in rating:
            r = rank[val]
            # remove current element from right side
            rightBIT.update(r, -1)

            # counts on left
            leftSmaller = leftBIT.query(r - 1)
            leftGreater = leftBIT.query(len(sorted_vals)) - leftBIT.query(r)

            # counts on right
            rightSmaller = rightBIT.query(r - 1)
            rightGreater = rightBIT.query(len(sorted_vals)) - rightBIT.query(r)

            res += leftSmaller * rightGreater + leftGreater * rightSmaller

            # add current element to left side
            leftBIT.update(r, 1)

        return res
