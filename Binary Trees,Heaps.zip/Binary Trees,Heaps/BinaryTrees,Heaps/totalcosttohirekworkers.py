class Solution(object):
    def totalCost(self, costs, k, candidates):
        """
        :type costs: List[int]
        :type k: int
        :type candidates: int
        :rtype: int
        """
        cost=0
        n=len(costs)
        l,r=0,n-1
        lheap=[]
        rheap=[]
        for _ in range(candidates):
            if l<=r:
                heapq.heappush(lheap,(costs[l],l))
                l+=1
        for _ in range(candidates):
            if l<=r:
                heapq.heappush(rheap,(costs[r],r))
                r-=1
        for _ in range(k):
            if lheap and rheap:
                if lheap[0]<rheap[0]:
                    cost+=heapq.heappop(lheap)[0]
                    if l<=r:
                        heapq.heappush(lheap,(costs[l],l))
                        l+=1
                else:
                    cost+=heapq.heappop(rheap)[0]
                    if l<=r:
                        heapq.heappush(rheap,(costs[r],r))
                        r-=1
            elif lheap:
                cost+=heapq.heappop(lheap)[0]
                if l<=r:
                    heapq.heappush(lheap,(costs[l],l))
                    l+=1
            else:
                cost+=heapq.heappop(rheap)[0]
                if l<=r:
                    heapq.heappush(rheap,(costs[r],r))
                    r-=1
        return cost


