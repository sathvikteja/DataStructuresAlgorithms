import heapq

n = int(input())
arr = list(map(int, input().split()))
minheap = []
for i in range(n):
    heapq.heappush(minheap, arr[i])
    if len(minheap) > 3:
        heapq.heappop(minheap)
    if len(minheap) < 3:
        print('-1')
    else:
        p = 1
        for x in minheap:
            p *= x
        print(p)
# for i in range(n):
#     if i<2:
#         print('-1')
#     else:
#         top=heapq.nlargest(3,arr[:i+1])
#         print(top[0]*top[1]*top[2])



