class BIT:
    def __init__(self, size):
        self.size = size + 2
        self.tree = [0] * self.size

    def update(self, index, val=1):
        while index < self.size:
            self.tree[index] += val
            index += index & -index

    def query(self, index):
        res = 0
        while index > 0:
            res += self.tree[index]
            index -= index & -index
        return res

class Solution:
    def countGoodTriplets(self, nums1, nums2):
        n = len(nums1)
        # Map values of nums2 according to indices in nums1
        pos_in_nums1 = [0] * n
        for idx, val in enumerate(nums1):
            pos_in_nums1[val] = idx

        mapped = [pos_in_nums1[val] for val in nums2]

        # Use two BITs to count increasing triplets
        bit1 = BIT(n)
        bit2 = BIT(n)
        result = 0

        for val in mapped:
            # Number of pairs ending here: number of elements before val in bit1
            pairs = bit1.query(val)
            # Add pairs to triplets count using bit2
            result += bit2.query(val)
            # Update bit2 with number of pairs ending at val
            bit2.update(val + 1, pairs)
            # Update bit1 with current element
            bit1.update(val + 1, 1)

        return result

