class SegmentTree:
    def __init__(self, arr):
        self.n = len(arr)
        # tree size 4n is safe
        self.tree = [0] * (4 * self.n)
        self._build(arr, 1, 0, self.n - 1)

    def _build(self, arr, idx, lo, hi):
        if lo == hi:
            self.tree[idx] = arr[lo]
        else:
            mid = (lo + hi) // 2
            self._build(arr, idx * 2, lo, mid)
            self._build(arr, idx * 2 + 1, mid + 1, hi)
            self.tree[idx] = max(self.tree[idx * 2], self.tree[idx * 2 + 1])

    def update(self, idx, lo, hi, pos, val):
        """
        Set basket at position pos to new value val (after usage), and update tree.
        """
        if lo == hi:
            self.tree[idx] = val
        else:
            mid = (lo + hi) // 2
            if pos <= mid:
                self.update(idx * 2, lo, mid, pos, val)
            else:
                self.update(idx * 2 + 1, mid + 1, hi, pos, val)
            self.tree[idx] = max(self.tree[idx * 2], self.tree[idx * 2 + 1])

    def query_first_ge(self, idx, lo, hi, target):
        """
        Find the leftmost index in [lo..hi] whose capacity >= target.
        Return the index, or -1 if none.
        """
        # If the maximum in this segment is < target, no such basket
        if self.tree[idx] < target:
            return -1
        # If this is a leaf, this is the position
        if lo == hi:
            return lo

        mid = (lo + hi) // 2
        # If left child segment has a basket ≥ target, go left
        if self.tree[idx * 2] >= target:
            return self.query_first_ge(idx * 2, lo, mid, target)
        else:
            # Otherwise go to right child
            return self.query_first_ge(idx * 2 + 1, mid + 1, hi, target)


class Solution(object):
    def numOfUnplacedFruits(self, fruits, baskets):
        """
        :type fruits: List[int]
        :type baskets: List[int]
        :rtype: int
        """
        n = len(baskets)
        seg = SegmentTree(baskets)
        unplaced = 0

        for fruit in fruits:
            # find the leftmost basket index that can hold this fruit
            pos = seg.query_first_ge(1, 0, n - 1, fruit)
            if pos == -1:
                # no basket can hold this fruit
                unplaced += 1
            else:
                # mark basket at pos as used (set capacity to something < 0)
                seg.update(1, 0, n - 1, pos, -1)

        return unplaced