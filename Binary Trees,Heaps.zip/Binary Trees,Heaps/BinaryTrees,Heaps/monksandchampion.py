import heapq
m,n=map(int,input().split())
arr=list(map(int,input().split()))
def pou(m,n,arr):
    maxheap=[-i for i in arr]
    heapq.heapify(maxheap)
    pounds=0
    while n>0:
        a=-heapq.heappop(maxheap)
        pounds+=a
        if a>1:
            heapq.heappush(maxheap,-(a-1))
        n-=1
    print(pounds)
pou(m,n,arr)

