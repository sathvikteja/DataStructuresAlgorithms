class BIT:
    def __init__(self, size):
        self.tree = [0] * (size + 2)
        self.size = size + 2

    def update(self, index, val=1):
        while index < self.size:
            self.tree[index] += val
            index += index & -index

    def query(self, index):
        res = 0
        while index > 0:
            res += self.tree[index]
            index -= index & -index
        return res


class Solution:
    def countQuadruplets(self, nums):
        n = len(nums)
        max_val = max(nums)

        left = [0] * n
        bit_left = BIT(max_val)
        for j in range(n):
            left[j] = bit_left.query(nums[j] - 1)
            bit_left.update(nums[j])


        right = [0] * n
        bit_right = BIT(max_val)
        for k in range(n - 1, -1, -1):
            right[k] = bit_right.query(max_val) - bit_right.query(nums[k])
            bit_right.update(nums[k])


        result = 0
        for j in range(1, n - 2):
            for k in range(j + 1, n - 1):
                if nums[j] < nums[k]:
                    result += left[j] * right[k]

        return result


