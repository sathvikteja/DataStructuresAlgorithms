class BIT:
    def __init__(self, size):
        self.tree = [0] * (size + 2)
        self.size = size + 2

    def update(self, index, val=1):
        while index < self.size:
            self.tree[index] += val
            index += index & -index

    def query(self, index):
        res = 0
        while index > 0:
            res += self.tree[index]
            index -= index & -index
        return res


class Solution:
    def numberOfPairs(self, nums1, nums2, diff):
        n = len(nums1)
        delta = [nums1[i] - nums2[i] for i in range(n)]

        # Coordinate compression
        all_values = list(set(delta + [d + diff for d in delta]))
        all_values.sort()
        value_to_idx = {v: i + 1 for i, v in enumerate(all_values)}  # 1-based for BIT

        bit = BIT(len(all_values))
        result = 0

        for d in delta:
            # Count number of previous elements <= d + diff
            idx = value_to_idx[d + diff]
            result += bit.query(idx)
            # Add current delta to BIT
            bit.update(value_to_idx[d])

        return result


