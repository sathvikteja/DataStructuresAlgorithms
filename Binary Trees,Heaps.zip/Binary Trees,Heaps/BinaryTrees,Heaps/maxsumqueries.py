from bisect import bisect_left

class SegmentTree:
    def __init__(self, n):
        self.N = 1
        while self.N < n:
            self.N <<= 1
        self.tree = [-1] * (2 * self.N)

    def update(self, idx, val):
        idx += self.N
        self.tree[idx] = max(self.tree[idx], val)
        while idx > 1:
            idx //= 2
            self.tree[idx] = max(self.tree[2*idx], self.tree[2*idx+1])

    def query(self, l, r):
        res = -1
        l += self.N
        r += self.N
        while l <= r:
            if l % 2 == 1:
                res = max(res, self.tree[l])
                l += 1
            if r % 2 == 0:
                res = max(res, self.tree[r])
                r -= 1
            l //= 2
            r //= 2
        return res


class Solution(object):
    def maximumSumQueries(self, nums1, nums2, queries):
        """
        :type nums1: List[int]
        :type nums2: List[int]
        :type queries: List[List[int]]
        :rtype: List[int]
        """
        n = len(nums1)
        q = len(queries)

        # coordinate compression on nums2 + query y
        all_y = sorted(set(nums2 + [y for _, y in queries]))
        comp = {v: i for i, v in enumerate(all_y)}

        # build (nums1, nums2, value) and sort by nums1 descending
        pairs = [(nums1[i], nums2[i], nums1[i] + nums2[i]) for i in range(n)]
        pairs.sort(reverse=True)

        # sort queries by x descending
        qlist = [(x, y, idx) for idx, (x, y) in enumerate(queries)]
        qlist.sort(reverse=True)

        seg = SegmentTree(len(all_y))
        res = [-1] * q
        j = 0

        for x, y, idx in qlist:
            # insert all pairs with nums1 >= x
            while j < n and pairs[j][0] >= x:
                _, b, val = pairs[j]
                seg.update(comp[b], val)
                j += 1

            # query range [y, ∞)
            pos = bisect_left(all_y, y)
            if pos < len(all_y):
                res[idx] = seg.query(pos, len(all_y) - 1)
            else:
                res[idx] = -1

        return res 