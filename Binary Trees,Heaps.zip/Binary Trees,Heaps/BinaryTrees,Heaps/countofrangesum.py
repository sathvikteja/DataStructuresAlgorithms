class SegmentTree:
    def __init__(self, n):
        self.n = n
        self.tree = [0] * (4 * n)

    def update(self, idx, l, r, pos, val):
        if l == r:
            self.tree[idx] += val
            return
        mid = (l + r) // 2
        if pos <= mid:
            self.update(2 * idx, l, mid, pos, val)
        else:
            self.update(2 * idx + 1, mid + 1, r, pos, val)
        self.tree[idx] = self.tree[2 * idx] + self.tree[2 * idx + 1]

    def query(self, idx, l, r, ql, qr):
        if qr < l or r < ql:
            return 0
        if ql <= l and r <= qr:
            return self.tree[idx]
        mid = (l + r) // 2
        return (self.query(2 * idx, l, mid, ql, qr) +
                self.query(2 * idx + 1, mid + 1, r, ql, qr))

class Solution(object):
    def countRangeSum(self, nums, lower, upper):
        """
        :type nums: List[int]
        :type lower: int
        :type upper: int
        :rtype: int
        """
        prefix = [0]
        for num in nums:
            prefix.append(prefix[-1] + num)

        # coordinate compression
        all_vals = set(prefix)
        for p in prefix:
            all_vals.add(p - lower)
            all_vals.add(p - upper)
        sorted_vals = sorted(all_vals)
        rank = {v: i + 1 for i, v in enumerate(sorted_vals)}  # 1-based index

        n = len(sorted_vals)
        seg = SegmentTree(n)
        res = 0

        for p in prefix:
            left = rank[p - upper]
            right = rank[p - lower]
            res += seg.query(1, 1, n, left, right)
            seg.update(1, 1, n, rank[p], 1)

        return res